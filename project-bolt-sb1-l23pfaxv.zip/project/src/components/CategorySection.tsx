import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import type { Article } from '@/data/types';
import { categories } from '@/data/categories';
import ArticleCard from './ArticleCard';

interface CategorySectionProps {
  categorySlug: string;
  articles: Article[];
}

export default function CategorySection({ categorySlug, articles }: CategorySectionProps) {
  const category = categories.find((c) => c.slug === categorySlug);
  if (!category || articles.length === 0) return null;

  const [featured, ...rest] = articles;

  return (
    <section className="py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl md:text-2xl font-bold text-gray-900 flex items-center gap-3">
          <span className="w-1 h-7 bg-blue-600 rounded-full inline-block" />
          {category.name}
        </h2>
        <Link
          to={`/category/${categorySlug}`}
          className="text-sm font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1 transition-colors"
        >
          View All
          <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <Link to={`/article/${featured.slug}`} className="group block bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow">
            <img
              src={featured.image}
              alt={featured.imageAlt}
              loading="lazy"
              className="w-full h-56 md:h-72 object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="p-5">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                {category.name}
              </span>
              <h3 className="text-lg md:text-xl font-bold text-gray-900 mt-2 group-hover:text-blue-600 transition-colors leading-snug">
                {featured.title}
              </h3>
              <p className="text-sm text-gray-600 mt-2 line-clamp-2">{featured.excerpt}</p>
            </div>
          </Link>
        </div>
        <div className="flex flex-col gap-4">
          {rest.slice(0, 2).map((article) => (
            <ArticleCard key={article.id} article={article} variant="compact" />
          ))}
        </div>
      </div>
    </section>
  );
}
