interface AdPlaceholderProps {
  variant?: 'banner' | 'rectangle' | 'sidebar' | 'footer' | 'inline';
  className?: string;
}

const sizeClasses: Record<NonNullable<AdPlaceholderProps['variant']>, string> = {
  banner: 'h-[90px] md:h-[100px] w-full',
  rectangle: 'h-[250px] w-full',
  sidebar: 'h-[300px] w-full',
  footer: 'h-[90px] md:h-[100px] w-full',
  inline: 'h-[200px] md:h-[250px] w-full',
};

export default function AdPlaceholder({ variant = 'banner', className = '' }: AdPlaceholderProps) {
  return (
    <div
      className={`flex items-center justify-center bg-gray-50 border border-gray-200 rounded-lg ${sizeClasses[variant]} ${className}`}
      aria-label="Advertisement placeholder"
      role="complementary"
    >
      <span className="text-xs font-semibold tracking-widest text-gray-400 uppercase select-none">
        Advertisement
      </span>
    </div>
  );
}
