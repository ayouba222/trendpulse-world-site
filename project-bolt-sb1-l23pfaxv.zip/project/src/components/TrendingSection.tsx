import { Link } from 'react-router-dom';
import type { Article } from '@/data/types';
import { TrendingUp } from 'lucide-react';

interface TrendingSectionProps {
  articles: Article[];
}

export default function TrendingSection({ articles }: TrendingSectionProps) {
  if (articles.length === 0) return null;

  return (
    <section className="py-8">
      <h2 className="text-xl md:text-2xl font-bold text-gray-900 flex items-center gap-3 mb-6">
        <TrendingUp className="w-6 h-6 text-red-500" />
        Trending Now
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {articles.slice(0, 4).map((article, index) => (
          <Link
            key={article.id}
            to={`/article/${article.slug}`}
            className="group flex gap-3 items-start p-4 bg-white rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-md transition-all"
          >
            <span className="text-3xl font-bold text-gray-200 group-hover:text-blue-200 transition-colors leading-none">
              {String(index + 1).padStart(2, '0')}
            </span>
            <div className="min-w-0">
              <h3 className="text-sm font-semibold text-gray-900 group-hover:text-blue-600 transition-colors line-clamp-3 leading-snug">
                {article.title}
              </h3>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
