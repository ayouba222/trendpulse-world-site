import { Link } from 'react-router-dom';
import type { Article } from '@/data/types';
import { categories } from '@/data/categories';
import { formatDateShort } from '@/utils/date';

interface ArticleCardProps {
  article: Article;
  variant?: 'default' | 'compact' | 'horizontal';
}

function getCategoryName(slug: string): string {
  return categories.find((c) => c.slug === slug)?.name ?? slug;
}

function getCategoryPath(slug: string): string {
  return `/category/${slug}`;
}

export default function ArticleCard({ article, variant = 'default' }: ArticleCardProps) {
  if (variant === 'compact') {
    return (
      <Link
        to={`/article/${article.slug}`}
        className="group flex gap-3 items-start"
      >
        <img
          src={article.image}
          alt={article.imageAlt}
          loading="lazy"
          className="w-20 h-20 object-cover rounded-lg flex-shrink-0"
        />
        <div className="min-w-0">
          <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600">
            {getCategoryName(article.category)}
          </span>
          <h4 className="text-sm font-semibold text-gray-900 group-hover:text-blue-600 transition-colors line-clamp-2 leading-snug mt-0.5">
            {article.title}
          </h4>
          <span className="text-xs text-gray-500 mt-1 block">{formatDateShort(article.publishedDate)}</span>
        </div>
      </Link>
    );
  }

  if (variant === 'horizontal') {
    return (
      <Link
        to={`/article/${article.slug}`}
        className="group flex flex-col sm:flex-row gap-4 sm:gap-6 items-start"
      >
        <div className="sm:w-64 flex-shrink-0">
          <img
            src={article.image}
            alt={article.imageAlt}
            loading="lazy"
            className="w-full h-48 sm:h-40 object-cover rounded-lg"
          />
        </div>
        <div className="flex-1">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
            {getCategoryName(article.category)}
          </span>
          <h3 className="text-lg font-bold text-gray-900 group-hover:text-blue-600 transition-colors mt-1 leading-snug">
            {article.title}
          </h3>
          <p className="text-sm text-gray-600 mt-2 line-clamp-2">{article.excerpt}</p>
          <div className="flex items-center gap-3 mt-3 text-xs text-gray-500">
            <span>{article.author}</span>
            <span aria-hidden="true">·</span>
            <span>{formatDateShort(article.publishedDate)}</span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <article className="group flex flex-col bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <Link to={`/article/${article.slug}`} className="block overflow-hidden">
        <img
          src={article.image}
          alt={article.imageAlt}
          loading="lazy"
          className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-500"
        />
      </Link>
      <div className="p-5 flex flex-col flex-1">
        <Link to={getCategoryPath(article.category)}>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 hover:underline">
            {getCategoryName(article.category)}
          </span>
        </Link>
        <h3 className="text-lg font-bold text-gray-900 mt-2 leading-snug">
          <Link to={`/article/${article.slug}`} className="hover:text-blue-600 transition-colors">
            {article.title}
          </Link>
        </h3>
        <p className="text-sm text-gray-600 mt-2 line-clamp-3 flex-1">{article.excerpt}</p>
        <div className="flex items-center gap-3 mt-4 text-xs text-gray-500">
          <span className="font-medium text-gray-700">{article.author}</span>
          <span aria-hidden="true">·</span>
          <span>{formatDateShort(article.publishedDate)}</span>
        </div>
      </div>
    </article>
  );
}
