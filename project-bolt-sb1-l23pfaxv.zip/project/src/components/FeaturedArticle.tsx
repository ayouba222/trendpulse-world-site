import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import type { Article } from '@/data/types';
import { categories } from '@/data/categories';
import { formatDate } from '@/utils/date';

interface FeaturedArticleProps {
  article: Article;
}

function getCategoryName(slug: string): string {
  return categories.find((c) => c.slug === slug)?.name ?? slug;
}

export default function FeaturedArticle({ article }: FeaturedArticleProps) {
  return (
    <article className="relative rounded-2xl overflow-hidden group bg-gray-900">
      <Link to={`/article/${article.slug}`} className="block">
        <img
          src={article.image}
          alt={article.imageAlt}
          className="w-full h-[400px] md:h-[520px] object-cover opacity-80 group-hover:opacity-90 group-hover:scale-105 transition-all duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-10">
          <div className="flex items-center gap-3 mb-3">
            <span className="inline-block bg-blue-600 text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded">
              {getCategoryName(article.category)}
            </span>
            <span className="text-white/80 text-sm">{formatDate(article.publishedDate)}</span>
          </div>
          <h1 className="text-2xl md:text-4xl font-bold text-white leading-tight max-w-3xl">
            {article.title}
          </h1>
          <p className="text-white/80 mt-3 text-sm md:text-base max-w-2xl line-clamp-2">
            {article.excerpt}
          </p>
          <span className="inline-flex items-center gap-2 mt-5 text-white text-sm font-semibold bg-white/10 backdrop-blur-sm px-5 py-2.5 rounded-full group-hover:bg-white/20 transition-colors">
            Read More
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </span>
        </div>
      </Link>
    </article>
  );
}
