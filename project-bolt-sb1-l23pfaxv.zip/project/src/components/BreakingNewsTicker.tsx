import { Link } from 'react-router-dom';
import type { Article } from '@/data/types';
import { categories } from '@/data/categories';
import { formatDate } from '@/utils/date';

interface BreakingNewsTickerProps {
  articles: Article[];
}

export default function BreakingNewsTicker({ articles }: BreakingNewsTickerProps) {
  if (articles.length === 0) return null;

  const tickerArticles = articles.slice(0, 6);

  return (
    <div className="bg-gray-900 text-white overflow-hidden border-y border-gray-800">
      <div className="max-w-7xl mx-auto px-4 flex items-center gap-4 h-11">
        <span className="flex-shrink-0 bg-red-600 text-white text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded animate-pulse">
          Breaking
        </span>
        <div className="relative flex-1 overflow-hidden">
          <div className="flex gap-8 animate-marquee whitespace-nowrap">
            {[...tickerArticles, ...tickerArticles].map((article, index) => {
              const cat = categories.find((c) => c.slug === article.category);
              return (
                <Link
                  key={`${article.id}-${index}`}
                  to={`/article/${article.slug}`}
                  className="text-sm text-gray-200 hover:text-white transition-colors inline-flex items-center gap-2"
                >
                  <span className="text-blue-400 font-semibold">{cat?.name}:</span>
                  <span className="truncate max-w-md">{article.title}</span>
                  <span className="text-gray-500 text-xs">{formatDate(article.publishedDate)}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
