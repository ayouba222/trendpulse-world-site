import type { Article } from './types';

export const articles: Article[] = [
  {
    id: 1,
    slug: 'ai-trends-that-could-change-everyday-life',
    title: 'The AI Trends That Could Change Everyday Life',
    category: 'technology',
    excerpt:
      'From personalized health assistants to smart-city infrastructure, a new wave of AI tools is moving from the lab into homes, workplaces, and public spaces — reshaping routines in ways both subtle and profound.',
    content: [
      'Artificial intelligence has spent the last decade mostly behind the scenes — powering search results, filtering spam, and quietly recommending what to watch next. That is changing fast. A new generation of AI tools is stepping out of data centers and into daily life, and the shift is happening more quickly than many analysts predicted.',
      'One of the most visible areas is personal health. Wearable devices paired with AI models can now flag irregular heart rhythms, suggest sleep adjustments, and even nudge users toward healthier habits with conversational coaching. Several startups are piloting AI assistants that help patients manage chronic conditions between doctor visits, sending summaries to physicians when patterns look concerning.',
      'In transportation, cities are beginning to deploy AI-driven traffic systems that adjust signal timing in real time based on flow. Early pilots in mid-sized U.S. cities reported modest but measurable reductions in commute times, and planners are watching closely to see whether the gains hold at scale.',
      'The workplace is another frontier. AI copilots for spreadsheets, legal research, and software development are no longer experimental — they are shipping in mainstream products. Workers who once feared automation are increasingly finding that these tools handle the tedious parts of the job, freeing them to focus on judgment and creativity.',
      'Not every trend is positive. Researchers warn about privacy erosion, bias in decision-making systems, and the energy footprint of large models. Policymakers are scrambling to keep up, and several states are drafting legislation that would require transparency when AI is used to make consequential decisions about consumers.',
      'The throughline is clear: AI is no longer a distant promise or a niche tool. It is becoming a layer of everyday infrastructure, as ordinary and invisible as electricity. The question for the next few years is not whether it will shape daily life, but how thoughtfully society chooses to steer it.',
    ],
    image: 'https://images.pexels.com/photos/5473956/pexels-photo-5473956.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Silhouette of a person with binary code projected on their face, representing AI technology',
    author: 'Maya Chen',
    publishedDate: '2026-09-05T08:30:00Z',
    updatedDate: '2026-09-05T14:00:00Z',
    tags: ['AI', 'technology', 'health', 'smart cities', 'future'],
    featured: true,
    trending: true,
  },
  {
    id: 2,
    slug: 'what-americans-are-watching-this-week',
    title: 'What Americans Are Watching This Week',
    category: 'us-news',
    excerpt:
      'A round-up of the stories capturing attention across the country — from local elections to cultural moments that are sparking conversations at dinner tables and online.',
    content: [
      'Every week, a handful of stories rise above the noise to become shared national conversations. This week is no exception, with several developments drawing attention from coast to coast.',
      'On the political front, a wave of local elections in several states is offering an early read on voter sentiment ahead of next year\'s midterms. Turnout in a few suburban districts has surprised observers, and analysts are parsing the results for signals about which issues are motivating voters.',
      'In culture, a independently produced documentary series has unexpectedly climbed to the top of streaming charts, dethroning several big-budget releases. The series, which follows everyday Americans navigating economic change, has struck a chord with viewers across the political spectrum.',
      'Economic data is also in the spotlight. A fresh jobs report came in stronger than expected, easing some recession fears but raising new questions about interest rates. Economists are divided on what the numbers mean for the months ahead, and households are paying close attention.',
      'Weather is making news too, as an early-season storm system moves across the Midwest. Communities are preparing, and emergency officials are urging residents to stay informed through local alerts.',
      'What ties these stories together is a sense that Americans are looking for clarity — about the economy, about their communities, and about the direction of the country. The stories that break through are the ones that speak to those underlying questions.',
    ],
    image: 'https://images.pexels.com/photos/15629500/pexels-photo-15629500.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Aerial view of a major American city skyline with skyscrapers',
    author: 'James Carter',
    publishedDate: '2026-09-06T10:00:00Z',
    updatedDate: '2026-09-06T10:00:00Z',
    tags: ['US news', 'elections', 'economy', 'culture'],
    featured: false,
    trending: true,
  },
  {
    id: 3,
    slug: 'technology-stories-everyone-is-talking-about',
    title: 'The Technology Stories Everyone Is Talking About',
    category: 'technology',
    excerpt:
      'From breakthroughs in quantum computing to the next wave of electric vehicles, here are the tech developments generating the most buzz in labs, boardrooms, and living rooms.',
    content: [
      'The pace of technology news can feel relentless, but a few stories this month have risen above the rest. Here is a guide to the developments that matter most.',
      'Quantum computing took a notable step forward when a research team demonstrated a new error-correction method that significantly reduces the resources needed for stable qubits. While practical quantum computers remain years away, the result suggests the field is finding viable engineering paths.',
      'Electric vehicles continue to gain momentum. A major automaker announced that its newest model will offer over 400 miles of range at a price point aimed squarely at the mass market. Charging infrastructure investments are expanding in parallel, with federal grants funding new stations along rural highways.',
      'On the software side, a wave of AI-powered coding assistants has reached general availability, and developers are reporting productivity gains — alongside new challenges around code review and security. The tools are improving fast, but best practices are still being written.',
      'Privacy remains a hot-button issue. A coalition of consumer groups is pushing for stronger data-protection rules, citing concerns about how personal information is used to train AI models. Several states are considering legislation that would give residents more control over their data.',
      'Augmented reality quietly crossed a milestone: a leading headset maker reported selling more units than expected, and a growing library of practical applications — from training simulations to remote assistance — is giving the technology a foothold beyond gaming.',
      'The common thread is that technology is no longer just about gadgets. It is about systems that reshape how people work, move, and interact — and the conversations around it are getting more serious as the stakes rise.',
    ],
    image: 'https://images.pexels.com/photos/9242888/pexels-photo-9242888.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Engineer working on a computer motherboard with a soldering tool',
    author: 'Priya Sharma',
    publishedDate: '2026-09-04T09:15:00Z',
    updatedDate: '2026-09-04T12:30:00Z',
    tags: ['technology', 'quantum computing', 'electric vehicles', 'AI', 'AR'],
    trending: true,
  },
  {
    id: 4,
    slug: 'biggest-business-trends-to-watch',
    title: 'The Biggest Business Trends to Watch',
    category: 'business',
    excerpt:
      'From the rise of remote-first companies to shifting supply chains, we break down the trends that are redefining how businesses operate and compete in 2026.',
    content: [
      'The business landscape is in the middle of a structural shift. Several trends that began as pandemic-era experiments have hardened into permanent features of the economy.',
      'Remote-first work is now the norm at a growing share of technology and professional-services firms. Companies that once resisted distributed teams have invested heavily in collaboration tools and async workflows. The result is a broader talent pool for employers and new flexibility for workers — but also new challenges around culture and mentorship.',
      'Supply chains are being restructured. After years of disruption, companies are diversifying suppliers, bringing some production closer to home, and investing in inventory buffers. The trend is reshaping logistics hubs and creating opportunities in regions that had lost manufacturing jobs.',
      'Sustainability has moved from a marketing talking point to a financial consideration. Investors are pressing companies for credible climate plans, and regulators are beginning to require standardized disclosure. Firms that treat this as a compliance exercise are struggling; those that treat it as a strategic priority are finding new markets.',
      'Artificial intelligence is changing how decisions get made. From demand forecasting to customer service, AI tools are being woven into core business processes. The companies seeing the best results are those investing in training and governance alongside the technology itself.',
      'Finally, the startup ecosystem is recalibrating. After a period of easy money, founders and investors are emphasizing profitability and sustainable growth. The result is a more disciplined environment — and arguably a healthier one for building durable companies.',
    ],
    image: 'https://images.pexels.com/photos/534216/pexels-photo-534216.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Stock market screen showing financial data and numbers',
    author: 'David Okonkwo',
    publishedDate: '2026-09-03T11:00:00Z',
    updatedDate: '2026-09-03T16:45:00Z',
    tags: ['business', 'remote work', 'supply chain', 'sustainability', 'startups'],
    trending: true,
  },
  {
    id: 5,
    slug: 'sports-moments-making-headlines-around-the-world',
    title: 'Sports Moments Making Headlines Around the World',
    category: 'sports',
    excerpt:
      'A stunning upset, a record-breaking performance, and a fairytale comeback — here are the sports stories that captured global attention this week.',
    content: [
      'Sports has a unique ability to stop the world and demand attention. This week delivered several moments that did exactly that.',
      'In tennis, an unseeded player reached the semifinals of a major tournament after defeating two top-ten opponents in consecutive matches. The run has captivated fans and sparked discussion about the depth of talent in the sport. The player\'s composure under pressure has drawn particular praise from commentators.',
      'Basketball saw a dramatic finish as a championship contender mounted a fourth-quarter comeback to force overtime and eventually win. The game is being replayed across highlight shows, and a last-second defensive play is already being called one of the plays of the season.',
      'In soccer, a club that was nearly relegated last season is now at the top of its league after a remarkable unbeaten run. The team\'s manager has been credited with a tactical overhaul that has made the squad both more disciplined and more entertaining to watch.',
      'Track and field delivered a record-breaking performance as an athlete set a new national mark in the hurdles. The run was notable not just for the time but for the conditions — a strong headwind made the achievement even more impressive.',
      'Beyond the results, the human stories are what make sports endure: the veteran savoring one more chance, the rookie announcing their arrival, the team that refused to quit. Those are the threads that connect a week of highlights into something larger.',
    ],
    image: 'https://images.pexels.com/photos/171568/pexels-photo-171568.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Tennis match at a major tournament with a full stadium of fans',
    author: 'Sofia Martinez',
    publishedDate: '2026-09-05T18:30:00Z',
    updatedDate: '2026-09-05T18:30:00Z',
    tags: ['sports', 'tennis', 'basketball', 'soccer', 'track and field'],
    trending: false,
  },
  {
    id: 6,
    slug: 'streaming-wars-enter-new-phase',
    title: 'The Streaming Wars Enter a New Phase',
    category: 'entertainment',
    excerpt:
      'As platforms consolidate and ad-supported tiers grow, the battle for your attention is shifting in ways that will change what gets made — and how much you pay to watch it.',
    content: [
      'The streaming industry entered its latest era of turbulence this year, and the contours of the new landscape are starting to come into focus.',
      'Consolidation is the headline story. Two major platforms announced plans to combine their libraries into a single subscription, a move that immediately drew scrutiny from regulators but also signaled where the industry is heading. Smaller services are under pressure to differentiate or partner.',
      'Ad-supported tiers are growing faster than premium subscriptions. For consumers, this means more free or low-cost options — but also more advertising in what was once an ad-free experience. Platforms are investing heavily in ad technology to make those impressions more valuable.',
      'Content strategy is shifting. The era of spending unlimited sums on prestige projects is giving way to a more balanced approach: a few big bets, a steady stream of mid-budget fare, and a growing reliance on live events and sports rights to drive engagement.',
      'For creators, the changes are double-edged. On one hand, new platforms and formats are creating opportunities. On the other, tighter budgets mean fewer guaranteed deals and more performance-based arrangements.',
      'For viewers, the practical upshot is a more complicated menu of choices. Deciding what to watch — and which subscriptions are worth keeping — has become its own kind of work. Tools that help people navigate the options are themselves becoming a business.',
    ],
    image: 'https://images.pexels.com/photos/2263436/pexels-photo-2263436.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Colorful live concert with vibrant lighting and an energetic crowd',
    author: 'Olivia Bennett',
    publishedDate: '2026-09-02T14:00:00Z',
    updatedDate: '2026-09-02T14:00:00Z',
    tags: ['entertainment', 'streaming', 'media', 'television'],
    trending: false,
  },
  {
    id: 7,
    slug: 'global-leaders-address-climate-finance-gap',
    title: 'Global Leaders Address the Climate Finance Gap',
    category: 'world',
    excerpt:
      'A major international summit focused on closing the gap between climate promises and actual funding, with developing nations pushing for concrete commitments.',
    content: [
      'Representatives from nearly 200 countries gathered this week for a summit focused on one of the thorniest problems in international climate policy: who pays for the transition to a low-carbon economy, and how much.',
      'The central tension is familiar. Developing nations argue that the countries most responsible for historical emissions have an obligation to fund adaptation and clean-energy projects in places that are bearing the brunt of climate impacts. Wealthier nations acknowledge the principle but have been slow to deliver on past pledges.',
      'This summit produced a few concrete steps. Several major economies announced new contributions to a fund aimed at helping vulnerable countries respond to climate-related disasters. The pledges, while meaningful, still fall short of what analysts say is needed.',
      'Beyond government funding, the summit put a spotlight on private finance. A coalition of investment firms committed to directing more capital toward green projects in emerging markets, though details on measurement and accountability remain to be worked out.',
      'Technology transfer was another theme. A number of agreements were signed to share clean-energy technology and expertise, particularly in areas like grid modernization and energy storage. Whether these agreements translate into real-world deployment will depend on implementation over the coming months.',
      'The summit ended with a joint communiqué that papered over some disagreements but established a framework for future negotiations. Observers called it a modest step forward — not the breakthrough many had hoped for, but not a breakdown either.',
    ],
    image: 'https://images.pexels.com/photos/8424530/pexels-photo-8424530.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Professional women engaged in a productive office meeting',
    author: 'Liam O\'Brien',
    publishedDate: '2026-09-04T07:00:00Z',
    updatedDate: '2026-09-04T09:30:00Z',
    tags: ['world', 'climate', 'finance', 'summit', 'policy'],
    trending: false,
  },
  {
    id: 8,
    slug: 'electric-vehicle-adoption-accelerates-in-rural-america',
    title: 'Electric Vehicle Adoption Accelerates in Rural America',
    category: 'technology',
    excerpt:
      'New charging corridors and falling prices are making EVs practical far from the coasts, reshaping how rural drivers think about their next car.',
    content: [
      'For years, electric vehicles were seen as a coastal phenomenon — popular in cities and suburbs, but a tough sell in rural areas where driving distances are longer and charging stations are sparse. That is starting to change.',
      'A combination of federal investment and private initiative has begun to fill in the charging map. New stations along rural highway corridors are making long-distance EV travel realistic for the first time in many parts of the country. State programs are adding stations at rest areas and small-town main streets.',
      'Falling battery costs have brought more affordable models to market. Several vehicles now offer 300-plus miles of range at prices that, after incentives, are competitive with comparable gas-powered cars. For rural drivers who often need a single vehicle that can handle everything from daily errands to long trips, range and price are the two numbers that matter.',
      'Local dealerships report a shift in attitudes. Where customers once asked whether EVs could handle winter weather or towing, many now arrive having already done their research. Test drives are increasingly the deciding factor rather than the starting point.',
      'Challenges remain. Charging reliability varies, and some rural areas still have large gaps in coverage. Electricians trained to install home chargers are in short supply in some regions. And for farmers and ranchers who depend on heavy-duty trucks, practical electric options are still on the horizon.',
      'Still, the direction is clear. The rural EV market, long written off, is becoming a real and growing part of the transition to electric transportation.',
    ],
    image: 'https://images.pexels.com/photos/4678065/pexels-photo-4678065.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Public electric vehicle charging station with eco-friendly design',
    author: 'Maya Chen',
    publishedDate: '2026-09-01T09:00:00Z',
    updatedDate: '2026-09-01T09:00:00Z',
    tags: ['technology', 'electric vehicles', 'rural', 'sustainability'],
    trending: false,
  },
  {
    id: 9,
    slug: 'remote-work-is-here-to-stay-survey-finds',
    title: 'Remote Work Is Here to Stay, Major Survey Finds',
    category: 'business',
    excerpt:
      'A comprehensive survey of employers and employees confirms that flexible work arrangements have become a permanent fixture — but the details vary sharply by industry.',
    content: [
      'The debate over remote work may finally be settling. A large-scale survey released this week found that flexible arrangements have hardened into permanent policy at a majority of knowledge-economy employers, with little sign of a broad return to pre-2020 norms.',
      'The survey, which polled thousands of employers and employees across industries, found that hybrid schedules — typically two or three days in the office — are the most common arrangement. Fully remote roles remain common in tech and professional services, while industries that require physical presence have largely returned to on-site work.',
      'Employees overwhelmingly value flexibility. When asked what they would trade for the ability to work remotely part of the week, a significant share said they would forgo a pay increase or consider a job change. Employers are paying attention, with many citing flexibility as a key retention tool.',
      'The picture is not uniformly positive. Managers report challenges with onboarding new hires, maintaining team cohesion, and ensuring that remote workers have equal access to opportunities. Some companies are experimenting with structured in-office days focused on collaboration rather than individual work.',
      'Commercial real estate is feeling the effects. Office vacancy rates remain elevated in many cities, and some buildings are being converted to residential use. The long-term impact on downtown economies is still unfolding.',
      'The survey\'s clearest finding is that the question is no longer whether remote work will persist, but how organizations will make it work well. The companies that figure that out are likely to have a durable advantage in attracting and keeping talent.',
    ],
    image: 'https://images.pexels.com/photos/68761/pexels-photo-68761.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Person working remotely from home with a laptop and plant on the desk',
    author: 'David Okonkwo',
    publishedDate: '2026-08-31T13:00:00Z',
    updatedDate: '2026-08-31T13:00:00Z',
    tags: ['business', 'remote work', 'survey', 'workplace'],
    trending: false,
  },
  {
    id: 10,
    slug: 'data-centers-and-the-energy-challenge',
    title: 'Data Centers and the Energy Challenge',
    category: 'technology',
    excerpt:
      'As AI workloads surge, the demand for data center capacity is straining power grids. Companies and regulators are racing to find solutions that keep the lights on.',
    content: [
      'The rapid growth of artificial intelligence has an infrastructure problem that is becoming impossible to ignore: data centers are using more electricity than ever, and the grid is feeling it.',
      'Training large AI models requires enormous computing power, and running those models for millions of users adds a steady load that does not ease when the sun goes down. Utilities in several regions have warned that they may not be able to meet the demand from planned data center expansions without significant new generation and transmission investment.',
      'Companies are responding on several fronts. Some are investing directly in renewable energy projects and battery storage to power their facilities. Others are siting new data centers in regions with surplus power or near new energy sources. A few are exploring novel approaches, including small nuclear reactors, though those remain years from deployment.',
      'Efficiency is also part of the answer. New chip designs promise more computation per watt, and software optimizations can reduce the energy cost of common workloads. But efficiency gains have historically been outpaced by growth in usage, and there is little reason to expect that pattern to change.',
      'Regulators are caught between competing pressures. Data centers bring investment and jobs, but they also strain infrastructure and raise environmental concerns. Several states are considering rules that would require large facilities to disclose energy use and source a percentage of their power from renewables.',
      'The tension between AI\'s promise and its energy footprint is likely to be one of the defining infrastructure debates of the decade. How it is resolved will shape both the technology landscape and the energy system that powers it.',
    ],
    image: 'https://images.pexels.com/photos/37730211/pexels-photo-37730211.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Modern server rack with blue lighting in a data center',
    author: 'Priya Sharma',
    publishedDate: '2026-08-30T08:00:00Z',
    updatedDate: '2026-08-30T08:00:00Z',
    tags: ['technology', 'data centers', 'energy', 'AI', 'infrastructure'],
    trending: false,
  },
  {
    id: 11,
    slug: 'basketball-playoffs-deliver-drama',
    title: 'Basketball Playoffs Deliver Drama and Surprises',
    category: 'sports',
    excerpt:
      'The playoff bracket has delivered upsets, overtime thrillers, and breakout performances — setting the stage for what could be an unforgettable postseason.',
    content: [
      'The basketball playoffs are in full swing, and they have not disappointed. From the opening tip, this postseason has delivered the kind of drama that fans will talk about for years.',
      'The biggest story is the emergence of a young team that few expected to advance past the first round. Led by a second-year point guard who is playing like a seasoned veteran, the squad has combined disciplined defense with an offense that moves the ball with rare unselfishness. Their series win over a higher-seeded opponent was the upset of the playoffs so far.',
      'On the other side of the bracket, a championship favorite has looked vulnerable. After dominating the regular season, the team has struggled to find its rhythm, and its coach is facing questions about rotation and strategy. Game five of their series went to double overtime, and the physical toll is showing.',
      'Individual performances have been spectacular. A veteran forward delivered a 40-point game that recalled his prime, while a rookie center has become the defensive anchor his team needed. The contrast between experience and youth is one of the storylines that makes the playoffs compelling.',
      'Off the court, the playoffs have also highlighted the global reach of the game. Broadcasts are reaching record international audiences, and social media highlights are crossing language barriers. The sport\'s growth in new markets is reflected in the diversity of players on the court.',
      'With several series still undecided, the path to the championship remains wide open. If the first rounds are any indication, basketball fans are in for a memorable finish.',
    ],
    image: 'https://images.pexels.com/photos/1752757/pexels-photo-1752757.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Basketball going through the hoop during a fast-paced game',
    author: 'Sofia Martinez',
    publishedDate: '2026-09-06T20:00:00Z',
    updatedDate: '2026-09-06T20:00:00Z',
    tags: ['sports', 'basketball', 'playoffs', 'championship'],
    trending: true,
  },
  {
    id: 12,
    slug: 'film-festival-reveals-standout-titles',
    title: 'Film Festival Reveals This Year\'s Standout Titles',
    category: 'entertainment',
    excerpt:
      'A diverse slate of films has emerged as the talk of the festival circuit, with independent productions holding their own against big-budget entries.',
    content: [
      'The fall film festival season is underway, and the first wave of reviews is in. As always, the festivals have offered a first look at the films that will shape the conversation for the rest of the year.',
      'The standout so far is a low-budget drama from a first-time director that drew a standing ovation at its premiere. The film, which tells an intimate story set in a small community, has been praised for its authenticity and restraint. Distribution rights were snapped up quickly after the screening.',
      'On the other end of the spectrum, a science-fiction epic from a major studio delivered spectacle on a grand scale. Critics were divided on the story but unanimous on the visual achievement. The film is expected to be a box-office force when it reaches wide release.',
      'Documentaries are making a particularly strong showing this year. A film about the history of a social movement has been hailed as essential viewing, and a nature documentary featuring never-before-seen footage has drawn gasps at every screening.',
      'International cinema continues to gain attention. A film from Southeast Asia has been celebrated for its innovative storytelling, and a European entry has drawn comparisons to the best work of a celebrated director. Subtitled films are finding audiences beyond the art-house circuit.',
      'For moviegoers, the festival season is a preview of what is to come. Several of these films will reach theaters in the coming months, and the early buzz suggests there is plenty to look forward to.',
    ],
    image: 'https://images.pexels.com/photos/3137890/pexels-photo-3137890.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    imageAlt: 'Framed movie posters in a cinema hallway under a Coming Soon sign',
    author: 'Olivia Bennett',
    publishedDate: '2026-09-03T15:30:00Z',
    updatedDate: '2026-09-03T15:30:00Z',
    tags: ['entertainment', 'film', 'festival', 'cinema', 'documentary'],
    trending: false,
  },
];

export function getArticleBySlug(slug: string): Article | undefined {
  return articles.find((a) => a.slug === slug);
}

export function getArticlesByCategory(category: string): Article[] {
  return articles.filter((a) => a.category === category);
}

export function getFeaturedArticle(): Article | undefined {
  return articles.find((a) => a.featured);
}

export function getTrendingArticles(): Article[] {
  return articles.filter((a) => a.trending);
}

export function getLatestArticles(limit?: number): Article[] {
  const sorted = [...articles].sort(
    (a, b) => new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime()
  );
  return limit ? sorted.slice(0, limit) : sorted;
}

export function getRelatedArticles(article: Article, limit = 3): Article[] {
  return articles
    .filter((a) => a.category === article.category && a.id !== article.id)
    .slice(0, limit);
}

export function searchArticles(query: string): Article[] {
  const q = query.toLowerCase().trim();
  if (!q) return [];
  return articles.filter(
    (a) =>
      a.title.toLowerCase().includes(q) ||
      a.excerpt.toLowerCase().includes(q) ||
      a.category.toLowerCase().includes(q) ||
      a.tags.some((t) => t.toLowerCase().includes(q))
  );
}
