export interface Article {
  id: number;
  slug: string;
  title: string;
  category: string;
  excerpt: string;
  content: string[];
  image: string;
  imageAlt: string;
  author: string;
  publishedDate: string;
  updatedDate: string;
  tags: string[];
  featured?: boolean;
  trending?: boolean;
}

export interface CategoryInfo {
  slug: string;
  name: string;
  description: string;
  longDescription: string;
}
