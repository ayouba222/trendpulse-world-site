import type { CategoryInfo } from './types';

export const categories: CategoryInfo[] = [
  {
    slug: 'us-news',
    name: 'U.S. News',
    description: 'The latest stories from across the United States.',
    longDescription:
      'Stay informed with comprehensive coverage of events shaping the United States — from policy debates in Washington to local stories that matter to communities nationwide.',
  },
  {
    slug: 'world',
    name: 'World',
    description: 'Global headlines and international affairs.',
    longDescription:
      'Explore breaking news and in-depth analysis from every corner of the globe. Our World section brings you stories that cross borders and connect us all.',
  },
  {
    slug: 'technology',
    name: 'AI & Technology',
    description: 'The future of AI, innovation, and digital life.',
    longDescription:
      'From artificial intelligence to consumer gadgets, we cover the technology trends reshaping how we work, communicate, and live. Discover the innovations driving tomorrow.',
  },
  {
    slug: 'business',
    name: 'Business',
    description: 'Markets, startups, and the economy explained.',
    longDescription:
      'Get the inside scoop on markets, emerging companies, and economic shifts. Our Business section breaks down complex financial stories into clear, actionable insight.',
  },
  {
    slug: 'sports',
    name: 'Sports',
    description: 'Scores, highlights, and stories from the world of sports.',
    longDescription:
      'From the gridiron to the tennis court, we bring you the moments that define competition. Catch up on scores, analysis, and the human stories behind the games.',
  },
  {
    slug: 'entertainment',
    name: 'Entertainment',
    description: 'Film, music, streaming, and pop culture.',
    longDescription:
      'Dive into the world of entertainment — from blockbuster releases to streaming hits and the artists shaping culture. Your front-row seat to what everyone is watching.',
  },
  {
    slug: 'trending',
    name: 'Trending',
    description: 'The stories everyone is talking about right now.',
    longDescription:
      'What is capturing the world\'s attention? Our Trending section surfaces the most-shared, most-discussed stories across all categories — the pulse of the public conversation.',
  },
];

export const navItems = [
  { label: 'Home', path: '/' },
  { label: 'U.S. News', path: '/category/us-news' },
  { label: 'World', path: '/category/world' },
  { label: 'AI & Technology', path: '/category/technology' },
  { label: 'Business', path: '/category/business' },
  { label: 'Sports', path: '/category/sports' },
  { label: 'Entertainment', path: '/category/entertainment' },
  { label: 'Trending', path: '/category/trending' },
];

export const footerNav = {
  quickLinks: [
    { label: 'Home', path: '/' },
    { label: 'U.S. News', path: '/category/us-news' },
    { label: 'World', path: '/category/world' },
    { label: 'Technology', path: '/category/technology' },
    { label: 'Business', path: '/category/business' },
    { label: 'Sports', path: '/category/sports' },
    { label: 'Entertainment', path: '/category/entertainment' },
    { label: 'Trending', path: '/category/trending' },
  ],
  company: [
    { label: 'About', path: '/about' },
    { label: 'Contact', path: '/contact' },
  ],
  legal: [
    { label: 'Privacy Policy', path: '/privacy-policy' },
    { label: 'Terms', path: '/terms' },
    { label: 'Disclaimer', path: '/disclaimer' },
  ],
};

export const socialLinks = [
  { label: 'Facebook', url: 'https://facebook.com', icon: 'facebook' as const },
  { label: 'Instagram', url: 'https://instagram.com', icon: 'instagram' as const },
  { label: 'X', url: 'https://x.com', icon: 'twitter' as const },
  { label: 'YouTube', url: 'https://youtube.com', icon: 'youtube' as const },
];

export const siteConfig = {
  name: 'TrendPulse World',
  tagline: "What's Trending. What Matters. What's Next.",
  description:
    'TrendPulse World is a modern digital news platform covering U.S. news, world affairs, AI and technology, business, sports, entertainment, and trending stories.',
  url: 'https://trendpulseworld.com',
  logoText: 'TrendPulse',
  logoAccent: 'World',
};
