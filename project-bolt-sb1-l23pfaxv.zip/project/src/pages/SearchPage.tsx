import { useSearchParams, Link } from 'react-router-dom';
import { useSEO } from '@/utils/seo';
import { searchArticles } from '@/data/articles';
import { categories } from '@/data/categories';
import ArticleCard from '@/components/ArticleCard';
import { Search as SearchIcon } from 'lucide-react';

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const results = query ? searchArticles(query) : [];

  useSEO({
    title: query ? `Search: ${query}` : 'Search',
    description: `Search results for "${query}" on TrendPulse World.`,
    path: `/search?q=${encodeURIComponent(query)}`,
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold text-gray-900 flex items-center gap-3">
          <SearchIcon className="w-7 h-7 text-gray-400" />
          Search Results
        </h1>
        {query && (
          <p className="text-gray-600 mt-2">
            {results.length > 0
              ? `Showing ${results.length} ${results.length === 1 ? 'result' : 'results'} for `
              : 'No results found for '}
            <span className="font-semibold text-gray-900">"{query}"</span>
          </p>
        )}
      </div>

      {query && results.length === 0 && (
        <div className="text-center py-20">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
            <SearchIcon className="w-8 h-8 text-gray-400" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">No results found</h2>
          <p className="text-gray-500 max-w-md mx-auto">
            We could not find any articles matching your search. Try different keywords or browse our categories.
          </p>
          <div className="flex items-center justify-center gap-2 mt-6 flex-wrap">
            {categories.map((cat) => (
              <Link
                key={cat.slug}
                to={`/category/${cat.slug}`}
                className="px-4 py-2 bg-gray-100 text-gray-700 text-sm font-medium rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                {cat.name}
              </Link>
            ))}
          </div>
        </div>
      )}

      {!query && (
        <div className="text-center py-20">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
            <SearchIcon className="w-8 h-8 text-gray-400" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Start searching</h2>
          <p className="text-gray-500">Use the search bar above to find articles.</p>
        </div>
      )}

      {results.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {results.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  );
}
