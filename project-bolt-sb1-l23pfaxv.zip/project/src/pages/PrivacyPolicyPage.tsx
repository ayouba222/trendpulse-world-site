import { useSEO } from '@/utils/seo';
import { siteConfig } from '@/data/categories';
import Breadcrumbs from '@/components/Breadcrumbs';

export default function PrivacyPolicyPage() {
  useSEO({
    title: 'Privacy Policy',
    description: `Privacy Policy for ${siteConfig.name}. Learn how we handle cookies, analytics, advertising, and personal information.`,
    path: '/privacy-policy',
  });

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <Breadcrumbs items={[{ label: 'Home', path: '/' }, { label: 'Privacy Policy' }]} />

      <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mt-6 mb-4">Privacy Policy</h1>
      <p className="text-sm text-gray-500 mb-8">Last updated: September 1, 2026</p>

      <div className="prose prose-lg max-w-none">
        <p className="text-gray-700 leading-relaxed">
          At {siteConfig.name}, we take your privacy seriously. This Privacy Policy explains how we collect, use, and protect your information when you visit our website.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">1. Information We Collect</h2>
        <p className="text-gray-700 leading-relaxed">
          We may collect the following types of information:
        </p>
        <ul className="text-gray-700 leading-relaxed space-y-2 list-disc pl-6 mt-2">
          <li><strong>Personal Information:</strong> Information you voluntarily provide, such as your email address when subscribing to our newsletter or filling out our contact form.</li>
          <li><strong>Usage Data:</strong> Information collected automatically, such as your IP address, browser type, device information, and pages visited.</li>
          <li><strong>Cookies:</strong> Small text files stored on your device to enhance your browsing experience.</li>
        </ul>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">2. How We Use Your Information</h2>
        <p className="text-gray-700 leading-relaxed">We use the information we collect to:</p>
        <ul className="text-gray-700 leading-relaxed space-y-2 list-disc pl-6 mt-2">
          <li>Provide and maintain our website and content.</li>
          <li>Send newsletters and updates (if you have subscribed).</li>
          <li>Respond to your inquiries and feedback.</li>
          <li>Analyze website traffic and user behavior to improve our content.</li>
          <li>Display relevant advertisements.</li>
        </ul>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">3. Cookies</h2>
        <p className="text-gray-700 leading-relaxed">
          We use cookies to improve your experience, analyze traffic, and serve advertisements. You can control cookies through your browser settings. Disabling cookies may affect some features of the website.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">4. Analytics</h2>
        <p className="text-gray-700 leading-relaxed">
          We may use third-party analytics tools, such as Google Analytics, to understand how visitors interact with our website. These tools collect information sent by your device, including the pages you visit, performance metrics, and other usage data.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">5. Advertising</h2>
        <p className="text-gray-700 leading-relaxed">
          We may display advertisements from third-party advertising networks, such as Google AdSense or other networks. These networks may use cookies and similar technologies to serve ads based on your prior visits to this and other websites. You can opt out of personalized advertising by visiting the applicable opt-out pages provided by these networks.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">6. Third-Party Services</h2>
        <p className="text-gray-700 leading-relaxed">
          We may use third-party services for analytics, advertising, email delivery, and other functions. These third parties have their own privacy policies, and we are not responsible for their practices. We encourage you to review their policies.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">7. Data Security</h2>
        <p className="text-gray-700 leading-relaxed">
          We take reasonable measures to protect your information from unauthorized access, alteration, or disclosure. However, no method of transmission over the internet is completely secure, and we cannot guarantee absolute security.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">8. Your Rights</h2>
        <p className="text-gray-700 leading-relaxed">You have the right to:</p>
        <ul className="text-gray-700 leading-relaxed space-y-2 list-disc pl-6 mt-2">
          <li>Access the personal information we hold about you.</li>
          <li>Request correction or deletion of your personal information.</li>
          <li>Opt out of receiving marketing communications.</li>
          <li>Disable cookies through your browser settings.</li>
        </ul>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">9. Children's Privacy</h2>
        <p className="text-gray-700 leading-relaxed">
          Our website is not directed to children under 13, and we do not knowingly collect personal information from children. If you believe a child has provided us with personal information, please contact us so we can take appropriate action.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">10. Changes to This Policy</h2>
        <p className="text-gray-700 leading-relaxed">
          We may update this Privacy Policy from time to time. We will notify you of significant changes by posting the updated policy on this page with a revised date.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">11. Contact Us</h2>
        <p className="text-gray-700 leading-relaxed">
          If you have questions about this Privacy Policy, please visit our <a href="/contact" className="text-blue-600 hover:underline">contact page</a> to reach out.
        </p>
      </div>
    </div>
  );
}
