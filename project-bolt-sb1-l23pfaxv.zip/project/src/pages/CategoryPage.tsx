import { useParams, Link } from 'react-router-dom';
import { useState } from 'react';
import { useSEO } from '@/utils/seo';
import { categories, siteConfig } from '@/data/categories';
import { getArticlesByCategory } from '@/data/articles';
import ArticleCard from '@/components/ArticleCard';
import Breadcrumbs from '@/components/Breadcrumbs';
import AdPlaceholder from '@/components/AdPlaceholder';
import { ArrowRight } from 'lucide-react';

const PAGE_SIZE = 6;

export default function CategoryPage() {
  const { category: slug } = useParams<{ category: string }>();
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);

  const category = categories.find((c) => c.slug === slug);
  const allArticles = slug ? getArticlesByCategory(slug) : [];

  useSEO({
    title: category ? `${category.name} News` : 'Category Not Found',
    description: category ? category.description : 'Category not found.',
    path: category ? `/category/${category.slug}` : '/category',
  });

  if (!category) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-20 text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Category Not Found</h1>
        <p className="text-gray-600 mb-6">The category you are looking for does not exist.</p>
        <Link to="/" className="text-blue-600 font-semibold hover:underline">
          Back to Home
        </Link>
      </div>
    );
  }

  const visibleArticles = allArticles.slice(0, visibleCount);
  const hasMore = visibleCount < allArticles.length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <Breadcrumbs
        items={[
          { label: 'Home', path: '/' },
          { label: category.name },
        ]}
      />

      <div className="mt-6 mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900">{category.name}</h1>
        <p className="text-gray-600 mt-2 max-w-2xl">{category.longDescription}</p>
      </div>

      <AdPlaceholder variant="banner" className="mb-8" />

      {allArticles.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-gray-500 text-lg">No articles in this category yet. Check back soon.</p>
        </div>
      ) : (
        <>
          {/* Featured story */}
          {allArticles[0] && (
            <div className="mb-8">
              <Link
                to={`/article/${allArticles[0].slug}`}
                className="group block bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-lg transition-shadow"
              >
                <div className="grid grid-cols-1 md:grid-cols-2">
                  <img
                    src={allArticles[0].image}
                    alt={allArticles[0].imageAlt}
                    loading="lazy"
                    className="w-full h-64 md:h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="p-6 md:p-8 flex flex-col justify-center">
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                      Featured Story
                    </span>
                    <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mt-2 group-hover:text-blue-600 transition-colors leading-tight">
                      {allArticles[0].title}
                    </h2>
                    <p className="text-gray-600 mt-3 line-clamp-3">{allArticles[0].excerpt}</p>
                    <span className="inline-flex items-center gap-2 mt-5 text-blue-600 font-semibold text-sm">
                      Read More
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>
                </div>
              </Link>
            </div>
          )}

          {/* Article Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {visibleArticles.slice(1).map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>

          {/* Load More */}
          {hasMore && (
            <div className="text-center mt-10">
              <button
                onClick={() => setVisibleCount((prev) => prev + PAGE_SIZE)}
                className="px-8 py-3 bg-gray-900 text-white font-semibold rounded-lg hover:bg-gray-800 transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Load More Articles
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
