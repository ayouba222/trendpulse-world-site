import { useSEO } from '@/utils/seo';
import { siteConfig } from '@/data/categories';
import Breadcrumbs from '@/components/Breadcrumbs';

export default function TermsPage() {
  useSEO({
    title: 'Terms of Use',
    description: `Terms of Use for ${siteConfig.name}. Read the rules and conditions for using our website.`,
    path: '/terms',
  });

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <Breadcrumbs items={[{ label: 'Home', path: '/' }, { label: 'Terms' }]} />

      <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mt-6 mb-4">Terms of Use</h1>
      <p className="text-sm text-gray-500 mb-8">Last updated: September 1, 2026</p>

      <div className="prose prose-lg max-w-none">
        <p className="text-gray-700 leading-relaxed">
          These Terms of Use govern your use of {siteConfig.name}. By accessing and using this website, you agree to be bound by these terms. If you do not agree with any part of these terms, please do not use our website.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">1. Use of Our Website</h2>
        <p className="text-gray-700 leading-relaxed">
          You agree to use this website for lawful purposes only. You must not use the site in any way that could damage, disable, or impair it, or that could interfere with any other party's use. You may not attempt to gain unauthorized access to any part of the website or its systems.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">2. Intellectual Property</h2>
        <p className="text-gray-700 leading-relaxed">
          All content published on {siteConfig.name} — including articles, images, logos, and design elements — is the property of {siteConfig.name} or its licensors. You may not reproduce, distribute, or republish our content without prior written permission.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">3. User Contributions</h2>
        <p className="text-gray-700 leading-relaxed">
          If our website allows user comments or submissions, you are responsible for the content you post. You agree not to post material that is defamatory, infringing, or otherwise unlawful. We reserve the right to remove any user content at our discretion.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">4. Third-Party Links</h2>
        <p className="text-gray-700 leading-relaxed">
          Our website may contain links to third-party websites. We are not responsible for the content, accuracy, or practices of those sites. Visiting any linked third-party site is at your own risk.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">5. Advertising</h2>
        <p className="text-gray-700 leading-relaxed">
          This website displays advertisements from third-party networks. We do not control which ads are shown and are not responsible for the products or services advertised. Clicking on advertisements is at your own discretion.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">6. Disclaimer of Warranties</h2>
        <p className="text-gray-700 leading-relaxed">
          This website is provided "as is" without warranties of any kind. We do not guarantee that the website will be error-free, secure, or available at all times. See our <a href="/disclaimer" className="text-blue-600 hover:underline">disclaimer</a> for more information.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">7. Limitation of Liability</h2>
        <p className="text-gray-700 leading-relaxed">
          {siteConfig.name} shall not be liable for any direct, indirect, or consequential damages arising from your use of this website or any content published on it.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">8. Changes to These Terms</h2>
        <p className="text-gray-700 leading-relaxed">
          We may update these Terms of Use at any time. Continued use of the website after changes are posted constitutes your acceptance of the revised terms.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">9. Contact Us</h2>
        <p className="text-gray-700 leading-relaxed">
          Questions about these Terms? Visit our <a href="/contact" className="text-blue-600 hover:underline">contact page</a>.
        </p>
      </div>
    </div>
  );
}
