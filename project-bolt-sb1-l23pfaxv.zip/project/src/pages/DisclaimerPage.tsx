import { useSEO } from '@/utils/seo';
import { siteConfig } from '@/data/categories';
import Breadcrumbs from '@/components/Breadcrumbs';

export default function DisclaimerPage() {
  useSEO({
    title: 'Disclaimer',
    description: `Editorial and content disclaimer for ${siteConfig.name}.`,
    path: '/disclaimer',
  });

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <Breadcrumbs items={[{ label: 'Home', path: '/' }, { label: 'Disclaimer' }]} />

      <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mt-6 mb-4">Disclaimer</h1>
      <p className="text-sm text-gray-500 mb-8">Last updated: September 1, 2026</p>

      <div className="prose prose-lg max-w-none">
        <p className="text-gray-700 leading-relaxed">
          The information provided by {siteConfig.name} on this website is for general informational purposes only. All information is provided in good faith; however, we make no representation or warranty of any kind regarding the accuracy, adequacy, validity, reliability, or completeness of any information on the site.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">Demo Content Notice</h2>
        <p className="text-gray-700 leading-relaxed">
          This website is currently a demonstration platform. The articles, headlines, and stories published here are original sample content created for illustration purposes only. They do not report on real events and should not be treated as factual news. Any resemblance to real persons, events, or organizations is coincidental.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">External Links Disclaimer</h2>
        <p className="text-gray-700 leading-relaxed">
          This website may contain links to external websites that are not provided or maintained by us. We do not guarantee the accuracy or completeness of any information on those external sites.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">Professional Advice Disclaimer</h2>
        <p className="text-gray-700 leading-relaxed">
          The content on this website does not constitute professional advice of any kind, including but not limited to legal, financial, medical, or investment advice. Always seek the guidance of a qualified professional before making decisions based on information you read here.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">Advertising Disclaimer</h2>
        <p className="text-gray-700 leading-relaxed">
          This website displays advertisements served by third-party advertising networks. We do not endorse and are not responsible for the products, services, or claims made in those advertisements.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">Accuracy Disclaimer</h2>
        <p className="text-gray-700 leading-relaxed">
          While we strive to provide accurate and up-to-date information, we make no warranties that the information on this site is free from errors. We are not liable for any losses or damages arising from the use of this website.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">Contact Us</h2>
        <p className="text-gray-700 leading-relaxed">
          If you have any questions about this disclaimer, please visit our <a href="/contact" className="text-blue-600 hover:underline">contact page</a>.
        </p>
      </div>
    </div>
  );
}
