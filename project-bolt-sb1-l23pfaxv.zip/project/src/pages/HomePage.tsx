import { useSEO, buildWebsiteJsonLd, buildOrganizationJsonLd } from '@/utils/seo';
import { siteConfig } from '@/data/categories';
import {
  getFeaturedArticle,
  getLatestArticles,
  getTrendingArticles,
  getArticlesByCategory,
} from '@/data/articles';
import FeaturedArticle from '@/components/FeaturedArticle';
import ArticleCard from '@/components/ArticleCard';
import CategorySection from '@/components/CategorySection';
import TrendingSection from '@/components/TrendingSection';
import BreakingNewsTicker from '@/components/BreakingNewsTicker';
import AdPlaceholder from '@/components/AdPlaceholder';
import Newsletter from '@/components/Newsletter';

export default function HomePage() {
  const featured = getFeaturedArticle();
  const latest = getLatestArticles(8);
  const trending = getTrendingArticles();
  const techArticles = getArticlesByCategory('technology');
  const businessArticles = getArticlesByCategory('business');
  const sportsArticles = getArticlesByCategory('sports');
  const entertainmentArticles = getArticlesByCategory('entertainment');
  const usNewsArticles = getArticlesByCategory('us-news');

  useSEO({
    title: siteConfig.name,
    description: siteConfig.description,
    path: '/',
    jsonLd: { ...buildWebsiteJsonLd(), ...buildOrganizationJsonLd() },
  });

  if (!featured) return null;

  return (
    <>
      <BreakingNewsTicker articles={latest} />
      <AdPlaceholder variant="banner" className="mt-4 mx-4 max-w-7xl xl:mx-auto" />

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Hero */}
        <FeaturedArticle article={featured} />
      </div>

      {/* Trending */}
      <div className="max-w-7xl mx-auto px-4">
        <TrendingSection articles={trending} />
      </div>

      {/* Latest News */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl md:text-2xl font-bold text-gray-900 flex items-center gap-3">
            <span className="w-1 h-7 bg-blue-600 rounded-full inline-block" />
            Latest News
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {latest.slice(0, 8).map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      </div>

      {/* Content Ad */}
      <div className="max-w-7xl mx-auto px-4">
        <AdPlaceholder variant="banner" />
      </div>

      {/* Category Sections */}
      <div className="max-w-7xl mx-auto px-4">
        <CategorySection categorySlug="us-news" articles={usNewsArticles} />
        <CategorySection categorySlug="technology" articles={techArticles} />
        <CategorySection categorySlug="business" articles={businessArticles} />
        <CategorySection categorySlug="sports" articles={sportsArticles} />
        <CategorySection categorySlug="entertainment" articles={entertainmentArticles} />
      </div>

      {/* Newsletter */}
      <div className="max-w-7xl mx-auto px-4">
        <Newsletter />
      </div>

      {/* Footer Ad */}
      <div className="max-w-7xl mx-auto px-4 pb-8">
        <AdPlaceholder variant="footer" />
      </div>
    </>
  );
}
