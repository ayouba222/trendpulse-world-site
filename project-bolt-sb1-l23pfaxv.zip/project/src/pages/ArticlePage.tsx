import { useParams, Link, Navigate } from 'react-router-dom';
import { useSEO, buildNewsArticleJsonLd, buildBreadcrumbJsonLd } from '@/utils/seo';
import { siteConfig, categories } from '@/data/categories';
import { getArticleBySlug, getRelatedArticles } from '@/data/articles';
import { formatDate } from '@/utils/date';
import ArticleCard from '@/components/ArticleCard';
import Breadcrumbs from '@/components/Breadcrumbs';
import SocialShare from '@/components/SocialShare';
import AdPlaceholder from '@/components/AdPlaceholder';
import Newsletter from '@/components/Newsletter';
import { Clock, User, Tag } from 'lucide-react';

export default function ArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const article = slug ? getArticleBySlug(slug) : undefined;

  if (!article) {
    return <Navigate to="/404" replace />;
  }

  const category = categories.find((c) => c.slug === article.category);
  const related = getRelatedArticles(article, 3);
  const articleUrl = `${siteConfig.url}/article/${article.slug}`;

  useSEO({
    title: article.title,
    description: article.excerpt,
    path: `/article/${article.slug}`,
    image: article.image,
    type: 'article',
    publishedDate: article.publishedDate,
    modifiedDate: article.updatedDate,
    author: article.author,
    jsonLd: {
      ...buildNewsArticleJsonLd(article),
      ...buildBreadcrumbJsonLd([
        { name: 'Home', url: siteConfig.url },
        { name: category?.name ?? '', url: `${siteConfig.url}/category/${article.category}` },
        { name: article.title, url: articleUrl },
      ]),
    },
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <Breadcrumbs
        items={[
          { label: 'Home', path: '/' },
          { label: category?.name ?? article.category, path: `/category/${article.category}` },
          { label: article.title },
        ]}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-6">
        {/* Main Content */}
        <div className="lg:col-span-2">
          {/* Category */}
          <Link
            to={`/category/${article.category}`}
            className="inline-block text-xs font-bold uppercase tracking-wider text-blue-600 hover:underline"
          >
            {category?.name ?? article.category}
          </Link>

          {/* Title */}
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mt-3 leading-tight">
            {article.title}
          </h1>

          {/* Meta */}
          <div className="flex items-center gap-4 mt-4 text-sm text-gray-500 flex-wrap">
            <span className="flex items-center gap-1.5">
              <User className="w-4 h-4" />
              {article.author}
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              {formatDate(article.publishedDate)}
            </span>
          </div>

          {/* Featured Image */}
          <img
            src={article.image}
            alt={article.imageAlt}
            className="w-full h-64 md:h-96 object-cover rounded-xl mt-6"
          />

          {/* Share */}
          <div className="mt-5">
            <SocialShare url={articleUrl} title={article.title} />
          </div>

          {/* Content - first 2 paragraphs */}
          <div className="prose prose-lg max-w-none mt-8">
            {article.content.slice(0, 2).map((paragraph, index) => (
              <p key={index} className="text-gray-700 leading-relaxed mb-4 text-lg">
                {paragraph}
              </p>
            ))}
          </div>

          {/* After intro ad */}
          <AdPlaceholder variant="rectangle" className="my-8" />

          {/* Content - remaining paragraphs */}
          <div className="prose prose-lg max-w-none">
            {article.content.slice(2).map((paragraph, index) => (
              <p key={index} className="text-gray-700 leading-relaxed mb-4 text-lg">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Tags */}
          <div className="mt-8 flex items-center gap-2 flex-wrap">
            <Tag className="w-4 h-4 text-gray-400" />
            {article.tags.map((tag) => (
              <span
                key={tag}
                className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>

          {/* Article end ad */}
          <AdPlaceholder variant="banner" className="my-8" />

          {/* Share again */}
          <div className="border-t border-gray-200 pt-6">
            <SocialShare url={articleUrl} title={article.title} />
          </div>
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-1">
          <div className="sticky top-24 space-y-6">
            <AdPlaceholder variant="sidebar" />

            {related.length > 0 && (
              <div className="bg-white rounded-xl border border-gray-200 p-5">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Related Stories</h3>
                <div className="space-y-4">
                  {related.map((rel) => (
                    <ArticleCard key={rel.id} article={rel} variant="compact" />
                  ))}
                </div>
              </div>
            )}

            <AdPlaceholder variant="sidebar" />
          </div>
        </aside>
      </div>

      {/* Related Articles Full Section */}
      {related.length > 0 && (
        <section className="mt-12 pt-8 border-t border-gray-200">
          <h2 className="text-xl md:text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
            <span className="w-1 h-7 bg-blue-600 rounded-full inline-block" />
            Related Stories
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {related.map((rel) => (
              <ArticleCard key={rel.id} article={rel} />
            ))}
          </div>
        </section>
      )}

      <Newsletter />
    </div>
  );
}
