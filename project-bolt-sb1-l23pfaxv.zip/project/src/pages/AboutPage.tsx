import { useSEO } from '@/utils/seo';
import { siteConfig } from '@/data/categories';
import Breadcrumbs from '@/components/Breadcrumbs';

export default function AboutPage() {
  useSEO({
    title: 'About Us',
    description: `Learn about ${siteConfig.name} — a modern digital news platform covering news, technology, business, sports, entertainment, and trending topics.`,
    path: '/about',
  });

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <Breadcrumbs items={[{ label: 'Home', path: '/' }, { label: 'About' }]} />

      <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mt-6 mb-6">About {siteConfig.name}</h1>

      <div className="prose prose-lg max-w-none">
        <p className="text-lg text-gray-700 leading-relaxed">
          {siteConfig.name} is a modern digital news platform dedicated to delivering the stories that matter — clearly, accurately, and without unnecessary noise. We cover U.S. news, world affairs, AI and technology, business, sports, entertainment, and the trending topics shaping public conversation.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">Our Mission</h2>
        <p className="text-gray-700 leading-relaxed">
          Our tagline says it best: <strong>"What's Trending. What Matters. What's Next."</strong> We aim to cut through the clutter and surface the stories that genuinely impact our readers' lives — whether that is a policy change in Washington, a breakthrough in artificial intelligence, or a cultural moment everyone is talking about.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">What We Cover</h2>
        <ul className="text-gray-700 leading-relaxed space-y-2 list-disc pl-6">
          <li><strong>U.S. News:</strong> Politics, policy, and stories from communities across the country.</li>
          <li><strong>World:</strong> International affairs and global developments.</li>
          <li><strong>AI & Technology:</strong> The innovations reshaping how we live and work.</li>
          <li><strong>Business:</strong> Markets, startups, and the economy — explained clearly.</li>
          <li><strong>Sports:</strong> Scores, analysis, and the human stories behind the games.</li>
          <li><strong>Entertainment:</strong> Film, music, streaming, and pop culture.</li>
          <li><strong>Trending:</strong> The stories everyone is talking about right now.</li>
        </ul>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">Our Values</h2>
        <p className="text-gray-700 leading-relaxed">
          We believe in clarity over sensationalism, context over clickbait, and respect for our readers' intelligence. Our goal is to inform, not to inflame. We are transparent about what we know and what we do not, and we treat corrections as a normal part of the process.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">A Note on Our Content</h2>
        <p className="text-gray-700 leading-relaxed">
          This website is currently a demonstration platform. The articles published here are original sample content created for illustration purposes. They do not report on real events and should not be treated as factual news.
        </p>

        <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-3">Get in Touch</h2>
        <p className="text-gray-700 leading-relaxed">
          Have a tip, a question, or feedback? We would love to hear from you. Visit our <a href="/contact" className="text-blue-600 hover:underline">contact page</a> to reach out.
        </p>
      </div>
    </div>
  );
}
